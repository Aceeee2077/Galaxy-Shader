#ifndef SE_ATMOSPHERE
#define SE_ATMOSPHERE
#include "/lib/noise.glsl"
#include "/lib/end_sky.glsl"
#include "/lib/weather.glsl"
#include "/lib/fogbow.glsl"
#include "/lib/secondary_rainbow.glsl"
#include "/lib/supernumerary.glsl"
#include "/lib/night_sky.glsl"
#include "/lib/aurora_corona.glsl"
#include "/lib/twilight_optics.glsl"
#include "/lib/noctilucent.glsl"
#include "/lib/ice_halo.glsl"
#include "/lib/ice_halo_extras.glsl"
#include "/lib/corona.glsl"
#include "/lib/scintillation.glsl"
#include "/lib/star_color.glsl"
#include "/lib/moonbow.glsl"
#include "/lib/zodiacal_band.glsl"
#include "/lib/nacreous.glsl"
#include "/lib/green_flash.glsl"
#include "/lib/eclipse_corona.glsl"
#include "/lib/antisolar_rays.glsl"
#include "/lib/moon.glsl"
#include "/lib/seasons.glsl"
#include "/lib/biome.glsl"
#include "/lib/celestial.glsl"
// Three-band analytic transmittance shared by the sun, twilight band and
// horizon light. Rayleigh scattering (blue-weighted), Mie extinction (nearly
// neutral) and a small ozone Chappuis absorption (green-weighted) are enough to
// reproduce the warm-to-red progression without a spectral LUT. The units are
// relative optical depths, not calibrated atmospheric coefficients.
vec3 atmosphereTransmittance(float sunHeight) {
    float h = max(sunHeight, 0.0);
    float airMass = 1.0 / (h + 0.03); // ~1 at zenith, ~33 at the geometric horizon
    float ozoneMass = sqrt(airMass);  // ozone sits above the dense lower air
    vec3 rayleigh = vec3(0.030, 0.060, 0.165);
    vec3 mie = vec3(0.013, 0.016, 0.021);
    vec3 ozone = vec3(0.010, 0.020, 0.005);
    return exp(-(rayleigh + mie) * airMass - ozone * ozoneMass);
}
vec3 sunlightColor() {
    float h = max(sunDirection().y,0.0);
    // Scattered light and aerosols soften the extreme geometric-horizon red.
    // Chroma only: the energy budget stays independent of exposure and glints.
    vec3 tint=atmosphereTransmittance(h);
    tint/=max(luminance(tint),1e-4);
    tint=mix(tint,vec3(1.0),0.05);
    float energy=mix(0.66,0.97,smoothstep(0.0,0.45,h));
    return tint*(energy/max(luminance(tint),1e-4));
}
// A warmer cut through the same transmittance for the low sky. The air mass is
// fixed below the solar disk so the band stays amber instead of turning black
// red as the sun reaches the horizon.
vec3 horizonSunTint() {
    vec3 tint=atmosphereTransmittance(0.06);
    tint/=max(luminance(tint),1e-4);
    return tint;
}
// A low-order diffuse sky probe, shared by surfaces, clouds and water. Its
// hemispheres follow sun elevation and weather without another sky ray march.
vec3 skyIrradiance(vec3 n) {
    float day=dayAmount();
    float lowSun=dawnDuskAmount();
    float overcast=weatherOvercastAmount();
    float skyHemisphere=sat(n.y*0.5+0.5);
    vec3 zenith=mix(vec3(0.012,0.018,0.030)*NIGHT_BRIGHTNESS,
                    vec3(0.32,0.335,0.35),day);
    vec3 horizon=mix(vec3(0.018,0.023,0.034)*NIGHT_BRIGHTNESS,
                     mix(vec3(0.38,0.34,0.29),vec3(0.36,0.30,0.24),lowSun*0.65),day);
    vec3 cloudy=mix(vec3(0.015,0.019,0.027)*NIGHT_BRIGHTNESS,
                    vec3(0.29,0.28,0.265),day);
    zenith=mix(zenith,cloudy,overcast*0.85);
    horizon=mix(horizon,cloudy,overcast*0.85);
    float sunward=0.5+0.5*dot(n.xz,sunDirection().xz);
    vec3 upper=zenith*skyHemisphere+horizon*(1.0-abs(n.y))*0.24;
    upper+=sunlightColor()*lowSun*day*sunward*(1.0-overcast)*0.025;
    // Warm ground bounce opens outdoor shade without lifting closed caves.
    vec3 ground=mix(vec3(0.003,0.004,0.006)*NIGHT_BRIGHTNESS,
                    vec3(0.080,0.067,0.047),day)*(1.0-skyHemisphere);
    // Low sun illuminates a small part of the dome. Reducing diffuse fill here
    // preserves sun/shade separation while keeping morning shade readable.
    float twilightFill=1.0-0.30*lowSun*day*(1.0-overcast);
    return (upper+ground)*twilightFill*(1.0-weatherStormAmount()*0.42)*
           (1.0-0.65*eclipseAmount())*SKYLIGHT_STRENGTH;
}
vec3 directionalRadiance() {
    float d = dayAmount();
    float sunHeight=sunDirection().y;
    // The old air-mass term and shared horizon fade suppressed low-angle sun
    // twice. Keep strong direct light once the solar disk clears the horizon;
    // the surface cosine still provides the natural grazing-angle falloff.
    float sunVisibility=smoothstep(-0.04,0.045,sunHeight);
    float lowSunGain=mix(1.12,1.0,smoothstep(0.10,0.60,sunHeight));
    vec3 sun = sunlightColor() * (3.35*SUN_INTENSITY*lowSunGain*sunVisibility) * seasonSunTint();
    // Moonlight follows the same illuminated fraction as the visible disk, so
    // a new moon no longer casts most of a full moon's directional light.
    float phase = 0.06 + 0.94 * moonPhaseFraction();
    vec3 moon = vec3(0.12,0.15,0.20)*NIGHT_BRIGHTNESS*phase*seasonSkyTint();
    moon*=smoothstep(0.0,0.12,abs(sunHeight));
    return mix(moon,sun,d)*(1.0-0.55*weatherOvercastAmount())*(1.0-0.64*weatherRainAmount())*
           (1.0-0.42*weatherStormAmount())*(1.0-0.88*eclipseAmount());
}
vec3 atmosphere(vec3 ray, bool disks) {
#if DIMENSION == -1
    float ash = fbm(ray.xz*4.0+frameTimeCounter*0.005,3);
    return mix(toLinear(fogColor)*0.9,vec3(0.12,0.024,0.008),0.4)+ash*vec3(0.018,0.006,0.002);
#elif DIMENSION == 1
    return endCosmos(ray,disks);
#else
    vec3 sun = sunDirection();
    vec3 sunTint = sunlightColor();
    float day = dayAmount(), mu = dot(ray,sun);
    float h = max(ray.y,0.0);
    float optical = 1.0/(0.18+pow(h,0.6));
    vec3 betaR = vec3(0.19,0.40,0.83);
    vec3 transmit = exp(-betaR*optical*0.28);
    float rayleigh = 0.75*(1.0+mu*mu);
    float g = 0.76;
    float mie = (1.0-g*g)/pow(max(1.0+g*g-2.0*g*mu,0.08),1.5);
    vec3 scatter = (1.0-transmit)*vec3(0.48,0.64,0.90)*rayleigh;
    // A pale horizon graduates into a blue zenith instead of a uniformly
    // saturated dome. Keep this broad component neutral even at low sun.
    scatter+=vec3(0.095,0.115,0.135)*pow(1.0-h,5.0)*smoothstep(-0.08,0.18,sun.y);
    scatter += sunTint*mie*0.012*smoothstep(-0.12,0.1,sun.y);
    float sunset = (1.0-smoothstep(0.03,0.35,abs(sun.y)))*smoothstep(-0.15,0.0,sun.y);
    // Stretch the sun-side lobe so the warm band is a broad glow rather than a
    // narrow stripe, and tint it through the same transmittance. Ozone keeps
    // the band amber instead of dull red while the zenith stays blue. A mild
    // chroma restore counteracts the desaturation of adding it over pale haze.
    float warmMu=pow(max(mu,0.0),3.2);
    vec3 warmBand=horizonSunTint()*0.46*sunset*pow(1.0-h,5.0)*(0.04+0.96*warmMu);
    warmBand=mix(vec3(luminance(warmBand)),warmBand,1.15);
    scatter+=warmBand;
    float golden=goldenHourAmount()*(1.0-weatherOvercastAmount());
    float goldenAir=golden*pow(1.0-h,2.5)*(0.08+0.92*pow(max(mu,0.0),4.0));
    scatter*=mix(vec3(1.0),vec3(0.98,0.91,0.68),goldenAir);
    scatter+=vec3(0.48,0.22,0.065)*golden*pow(1.0-h,2.5)*
             (0.06+0.94*pow(max(mu,0.0),4.0));
    vec3 night = mix(vec3(0.006,0.009,0.018),vec3(0.018,0.023,0.037),pow(1.0-h,3.0))*NIGHT_BRIGHTNESS;
    vec3 sky = mix(night,scatter,day);
    // A blue twilight dome survives after direct sunlight fades. Local pink
    // horizon light replaces the previous broad yellow overlay.
    float blueHour=exp(-pow((sun.y+0.075)/0.065,2.0));
    sky+=vec3(0.012,0.025,0.065)*blueHour*(0.35+0.65*h);
    sky+=vec3(0.065,0.022,0.032)*blueHour*pow(1.0-h,6.0)*
         (0.2+0.8*pow(max(mu,0.0),2.0));
    // Subtle daily variation keeps consecutive Minecraft days from looking identical.
    sky *= mix(0.94, 1.06, dayVariation()) * seasonSkyTint() * biomeSkyTint();
    float eclipse=eclipseAmount();
    sky *= 1.0-0.72*eclipse;
    float overcast=weatherOvercastAmount();
    // Twilight and dark-sky optics share one strength. The Earth's shadow only
    // darkens the anti-solar dome, while the Belt of Venus, zodiacal cone and
    // airglow add light; all are suppressed by cloud and storm cover.
    float opticsStrength=TWILIGHT_OPTICS*(1.0-overcast);
    sky*=1.0-0.20*earthShadowMask(ray,sun)*opticsStrength;
    sky+=twilightOptics(ray,sun,overcast)*TWILIGHT_OPTICS;
    vec3 cloudySky=mix(vec3(0.16,0.20,0.25),vec3(0.055,0.070,0.095),weatherStormAmount());
    cloudySky*=mix(0.42,1.0,day);
    // Low sunlight still colors rain clouds; midday and night retain cool storms.
    cloudySky=mix(cloudySky,vec3(0.40,0.31,0.17),sunset*0.72);
    sky=mix(sky,cloudySky,overcast*0.74);
    sky *= 1.0-0.22*weatherStormAmount();
    // A compact solar aureole stays near the disk. The tight lobe decays faster
    // in blue and the wide lobe slower, so the core reads warm while the outer
    // aureole gains a cool fringe. This is an angular colour split, not a
    // screen-space tint, and clouds still composite over it.
    float solarAngle=max(1.0-mu,0.0);
    float radius=SUN_ANGULAR_RADIUS*(PI/180.0);
    float diskEdge=1.0-cos(radius);
    float haloDistance=max(solarAngle-diskEdge,0.0);
    vec3 tightHalo=exp(-haloDistance*vec3(1400.0,1800.0,2400.0));
    vec3 wideHalo=exp(-haloDistance*vec3(560.0,500.0,440.0));
    vec3 haloColor=sunTint*tightHalo*1.70+
                   mix(sunTint,vec3(0.72,0.82,1.0),0.55)*wideHalo*0.10;
    sky+=haloColor*day*smoothstep(-0.04,0.045,sun.y)*
         (1.0-overcast)*(1.0-0.95*eclipse)*SUN_INTENSITY;
    if (disks && ray.y>-0.02) {
        // Keep the disk edge stable with resolution; the angular radius also
        // controls contact-hardening shadows, rather than an unrelated size.
        float diskWidth=max(fwidth(mu),diskEdge*0.06);
        float solarDisk=smoothstep(cos(radius)-diskWidth,cos(radius)+diskWidth,mu);
        float sunVisibility=day*(1.0-overcast)*(1.0-0.95*eclipse)*SUN_INTENSITY;
#if GREEN_FLASH > 0
        // A brief green rim on the top limb during the last degree of sunset.
        // Dim the warm disk under the rim so the additive green is visible.
        float flashMask=greenFlashMask(ray,sun,SUN_ANGULAR_RADIUS)*
                        GREEN_FLASH*sunVisibility;
        sunVisibility*=1.0-0.85*flashMask;
        sky += greenFlash(ray,sun,sunVisibility,SUN_ANGULAR_RADIUS)*GREEN_FLASH;
#endif
        sky += sunTint*18.0*solarDisk*sunVisibility;
        sky += vec3(1.00,0.82,0.55)*exp(-pow((1.0-mu)*58.0,2.0))*eclipse*2.2;
        sky += eclipseCorona(ray, sun, eclipse * (1.0 - overcast),
                             frameTimeCounter);
        sky += moonSky(ray,1.0-day,overcast);
        vec2 starUV = vec2(atan(ray.z,ray.x),asin(clamp(ray.y,-1.0,1.0)))*vec2(700.0,900.0);
        float starCell = hash12(floor(starUV));
        float star = step(0.996,starCell)*pow(max(1.0-length(fract(starUV)-0.5)*2.0,0.0),4.0);
        float twinkle = starScintillation(hash12(floor(starUV)+13.7),ray.y,
                                          frameTimeCounter,STAR_SCINTILLATION);
        float starBrightness = star*twinkle*0.7*(1.0-day)*(1.0-overcast)*
                               smoothstep(0.0,0.2,ray.y);
#if STAR_COLOR > 0
        sky += starColour(hash12(floor(starUV)+57.1),
                          hash12(floor(starUV)+31.7)) * starBrightness;
#else
        sky += vec3(starBrightness);
#endif
#if COSMIC_SKY_QUALITY > 0
        float cosmicNight = (1.0-day)*(1.0-overcast*0.82);
        sky += galaxyNebula(ray)*cosmicNight*(0.55+0.45*float(COSMIC_SKY_QUALITY>=2))*COSMIC_SKY_STRENGTH;
#if COSMIC_SKY_QUALITY >= 2
        float auroraStrength = cosmicNight*biomeAuroraBoost()*(1.0+auroraStormAmount()*0.9);
        sky += auroraSky(ray,auroraStrength)*COSMIC_SKY_STRENGTH;
        sky += auroraCorona(ray,auroraStrength,frameTimeCounter)*COSMIC_SKY_STRENGTH;
        sky += shootingStars(ray)*cosmicNight*(1.0+meteorShowerAmount()*2.2);
        sky += cometSky(ray,cosmicNight);
        sky += supernovaSky(ray,cosmicNight);
#endif
#endif
    }
#if FOGBOW > 0
    // Fog droplets smear refraction into a broad white bow. It takes over once
    // active rain has stopped but the air is still wet, cloudy and thick.
    float fogBowAmount = smoothstep(0.95, 1.30, biomeFogDensity()) *
                         smoothstep(0.25, 0.70, weatherWetness()) *
                         smoothstep(0.20, 0.70, overcast) *
                         (1.0 - smoothstep(0.10, 0.40, weatherRainAmount()));
    if (fogBowAmount > 0.0) {
        sky += fogbow(ray, sun, fogBowAmount, day) * FOGBOW;
    }
#endif
#if WEATHER_QUALITY > 0
    // A single ordered spectral arc around the anti-solar point. Iris wetness
    // lets it linger briefly after rain while direct daylight is returning.
    float rainbowMoisture = max(weatherRainAmount(), weatherWetness() * 0.72);
    if (rainbowMoisture > 0.025 && sun.y > 0.02 && ray.y > 0.0) {
        float angle = acos(clamp(dot(ray, -sun), -1.0, 1.0));
        float spectral = (angle - 0.655) / 0.145;
        if (spectral > 0.0 && spectral < 1.0) {
            float edge = smoothstep(0.0, 0.09, spectral) *
                         (1.0 - smoothstep(0.91, 1.0, spectral));
            vec3 bow = mix(vec3(0.40, 0.16, 0.74), vec3(0.10, 0.32, 0.95), smoothstep(0.06, 0.24, spectral));
            bow = mix(bow, vec3(0.06, 0.80, 0.40), smoothstep(0.23, 0.46, spectral));
            bow = mix(bow, vec3(0.98, 0.86, 0.12), smoothstep(0.46, 0.68, spectral));
            bow = mix(bow, vec3(1.0, 0.22, 0.07), smoothstep(0.68, 0.94, spectral));
            float clearSky = 1.0 - overcast * 0.72;
            sky += bow * edge * smoothstep(0.0, 0.10, ray.y) *
                   rainbowMoisture * clearSky * day * 0.62;
        }
    }
#endif
#if WEATHER_QUALITY > 0
    // Outside the primary bow the second internal reflection draws a fainter,
    // colour-reversed arc near 51 degrees. The gap between the two bows is
    // Alexander's dark band, slightly darker than the sky on either side.
    if (rainbowMoisture > 0.025 && ray.y > 0.0) {
        float bowAngle = acos(clamp(dot(ray, -sun), -1.0, 1.0));
        float alexander = smoothstep(0.72, 0.76, bowAngle) *
                          (1.0 - smoothstep(0.83, 0.87, bowAngle));
        sky *= 1.0 - 0.08 * alexander * rainbowMoisture *
               (1.0 - overcast * 0.72) * day;
        sky += secondaryRainbow(ray, sun, rainbowMoisture, overcast, day);
        sky += supernumeraryArcs(ray, sun, rainbowMoisture, overcast, day);
    }
#endif
#if MOONBOW > 0 && WEATHER_QUALITY > 0
    // The night counterpart of the anti-solar rainbow. It shares the moisture
    // source so a moonbow lingers after rain in the same way; moonlight and the
    // illuminated fraction decide how much of the silver arc is visible.
    float moonbowMoisture = max(weatherRainAmount(), weatherWetness() * 0.72);
    if (moonbowMoisture > 0.025) {
        vec3 moonBowDir = safeNormalize(worldDirection(moonPosition));
        sky += moonbow(ray, moonBowDir, moonPhaseFraction(), moonbowMoisture,
                       1.0 - day, overcast) * MOONBOW;
    }
#endif
#if ICE_HALOS > 0
    // Cirrus ice crystals draw a 22-degree ring around the sun, with parhelia
    // and a pillar when the sun is low. The moon earns only the ring: its
    // light is too weak to produce the other crystals in this approximation.
    float iceWeather = (1.0 - overcast) * (1.0 - 0.55 * weatherRainAmount());
    float solarHalo = day * smoothstep(-0.015, 0.05, sun.y) * iceWeather;
    sky += iceHalo(ray, sun, solarHalo, sunTint, 0.0) * ICE_HALOS;
    if (disks) {
        vec3 moonDir = safeNormalize(worldDirection(moonPosition));
        float lunarHalo = (1.0 - day) * (0.10 + 0.90 * moonPhaseFraction()) *
                          smoothstep(0.0, 0.10, moonDir.y) * iceWeather;
        sky += iceHalo(ray, moonDir, lunarHalo, vec3(0.72, 0.80, 1.0), 1.0) *
               ICE_HALOS;
    }
#endif
#if ICE_HALO_COMPANIONS > 0
    // The broad 46-degree ring, and the horizontal circumhorizontal arc when
    // the sun is high enough for plate crystals to refract it.
    float companionWeather = (1.0 - overcast) * (1.0 - 0.65 * weatherRainAmount());
    float companionSun = day * smoothstep(0.02, 0.10, sun.y) * companionWeather;
    sky += iceHaloCompanions(ray, sun, companionSun) * ICE_HALO_COMPANIONS;
#endif
#if LUNAR_CORONA > 0
    // Diffraction rings in thin cloud around a bright moon. They are a compact
    // night feature, so the moon direction is tested before the rings are built.
    vec3 coronaMoon = safeNormalize(worldDirection(moonPosition));
    float coronaWeather = 1.0 - 0.5 * weatherRainAmount();
    sky += lunarCorona(ray, coronaMoon, moonPhaseFraction(), overcast, 1.0 - day) *
           coronaWeather * LUNAR_CORONA;
#endif
#if ANTISOLAR_RAYS > 0
    // Cloud-shadow spokes converging on the anti-solar point at low sun.
    sky += anticrepuscularRays(ray, sun, overcast) * ANTISOLAR_RAYS;
#endif
#if ZODIACAL_BAND > 0
    // The night-time continuation of the zodiacal light: a faint ecliptic band
    // and the brighter anti-solar gegenschein. Clouds remove both.
    sky += zodiacalBand(ray, sun, overcast) * ZODIACAL_BAND;
#endif
#if NACREOUS_CLOUDS > 0
    // Polar stratospheric clouds: pastel lenticular sheets in the same twilight
    // window, weighted toward winter and drawn before the noctilucent layer.
    sky += nacreousClouds(ray, sun, overcast, seasonWeights().w);
#endif
#if NOCTILUCENT_CLOUDS > 0
    // High mesospheric ice clouds remain sunlit after the lower sky has gone
    // dark. They sit above the cosmic layer, so stars and the galaxy are
    // correctly veiled instead of shining through the cloud sheet.
    sky += noctilucentClouds(ray, sun, overcast, seasonWeights().y);
#endif
    sky += lightningBoltPosition.w*vec3(0.24,0.30,0.43)*(0.45+0.55*weatherStormAmount());
    return max(sky,vec3(0.0));
#endif
}
#endif
