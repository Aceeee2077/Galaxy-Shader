#version 330 compatibility
#define DIMENSION 1
#define TERRAIN
#include "/program/effect.fsh"
