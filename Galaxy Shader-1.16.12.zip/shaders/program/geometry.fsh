varying float vCloudShadow;
#include "/lib/common.glsl"
#include "/lib/lighting.glsl"
#include "/lib/weather.glsl"
#include "/lib/seasons.glsl"
#include "/lib/biome.glsl"
uniform sampler2D texture, normals, specular;
uniform vec4 entityColor;
uniform float alphaTestRef;
varying vec2 vTex, vLight;
varying vec4 vColor;
varying vec3 vPlayer, vNormal, vTangent, vBitangent;
// Material IDs are categorical; perspective interpolation can cross emission boundaries.
flat in float vId;
/* DRAWBUFFERS:0123 */
void main() {
    vec4 tex=texture2D(texture,vTex)*vColor;
#ifdef TERRAIN
    // separateAo puts terrain occlusion in vertex alpha, not opacity.
    tex.a=texture2D(texture,vTex).a;
#endif
#ifdef BASIC
    tex=vColor;
#endif
    if(tex.a<max(alphaTestRef,0.001)) discard;
#ifdef ENTITY
    tex.rgb=mix(tex.rgb,entityColor.rgb,entityColor.a);
#endif
    Material m=defaultMaterial(toLinear(tex.rgb),safeNormalize(vNormal));
    float rainSplash=0.0;
#if PBR_MODE == 2 || (PBR_MODE == 1 && defined(MC_TEXTURE_FORMAT_LAB_PBR))
#if defined(TERRAIN) || defined(BLOCK_ENTITY)
    if(dot(vTangent,vTangent)>0.5) {
        decodeLabPBR(m,texture2D(normals,vTex),texture2D(specular,vTex),
                     mat3(safeNormalize(vTangent),safeNormalize(vBitangent),m.normal));
    }
#endif
#endif
#ifdef TERRAIN
    m.ao*=vColor.a;
#endif
    if(vId>=10101.0 && vId<=10106.0) {
        // Preserve the atlas silhouette; only bright texels become incandescent.
        float bright=smoothstep(0.20,0.75,max(tex.r,max(tex.g,tex.b)));
        m.emission=max(m.emission,bright*0.8);
        m.albedo=mix(m.albedo,m.albedo*emissionTint(vId)*1.6,bright*0.45);
    }
    if(vId>=10110.0 && vId<=10117.0) {
        // Ore flecks have color contrast; the neutral host rock stays dark.
        float hi=max(tex.r,max(tex.g,tex.b));
        float lo=min(tex.r,min(tex.g,tex.b));
        float chroma=hi-lo;
        float vein=smoothstep(0.25,0.58,hi)*smoothstep(0.035,0.17,chroma);
        if(vId==10115.0) vein=smoothstep(0.34,0.67,hi)*
                               smoothstep(0.018,0.09,chroma);
        if(vId==10117.0) vein=smoothstep(0.23,0.55,hi)*
                               smoothstep(0.025,0.12,chroma);
        vec3 mineralColor=emissionTint(vId);
        m.albedo=mix(m.albedo,mineralColor*0.72,vein*0.70);
        m.emission=max(m.emission,vein*1.20);
        m.roughness=mix(m.roughness,0.22,vein*0.65);
    }
#ifdef EMISSIVE
    m.emission=max(m.emission,0.8);
#endif
#if WET_SURFACES == 1 && DIMENSION == 0
    float foliage=step(10000.5,vId)*step(vId,10005.5);
    float upward=mix(max(m.normal.y,0.0),0.58+0.42*max(m.normal.y,0.0),foliage);
    float exposure=smoothstep(0.78,0.98,vLight.y)*upward;
    float wet=weatherWetness()*exposure;
    m.albedo*=1.0-0.25*wet;
    m.roughness=mix(m.roughness,min(m.roughness,0.10),wet*0.86);
    // Dry surfaces, caves and downward faces all reach wet == 0 exactly; the
    // puddle noise and both mixes are then no-ops, so skip them entirely.
    if(wet>0.0) {
        float puddleNoise=valueNoise((vPlayer.xz+cameraPosition.xz)*0.35);
        float puddle=step(0.58,puddleNoise)*smoothstep(0.80,0.98,vLight.y)*upward*wet;
        m.roughness=mix(m.roughness,0.02,puddle);
        m.albedo*=1.0-0.12*puddle;
    }
#if WEATHER_QUALITY > 0
    float activeRain=weatherRainAmount()*exposure;
    if(activeRain>0.001) {
        vec3 impact=rainRippleField(vPlayer.xz+cameraPosition.xz,2.8);
        m.normal=safeNormalize(m.normal+vec3(impact.x,0.0,impact.y)*activeRain*0.028*RIPPLE_STRENGTH);
        rainSplash=pow(impact.z,2.5)*activeRain*RIPPLE_STRENGTH;
    }
#endif
#endif
#if DIMENSION == 0
    float seasonFoliage=step(10000.5,vId)*step(vId,10005.5);
    if(seasonFoliage>0.5) {
        vec4 sw=seasonWeights();
        float leafNoise=valueNoise((vPlayer.xz+cameraPosition.xz)*0.08);
        vec3 autumnTint=mix(vec3(1.38,0.52,0.16),vec3(1.45,0.80,0.18),leafNoise);
        vec3 leafTint=vec3(0.90,1.16,0.70)*sw.x + vec3(1.00,1.00,1.00)*sw.y +
                     autumnTint*sw.z + vec3(0.74,0.70,0.56)*sw.w;
        m.albedo*=mix(vec3(1.0),leafTint,sat(SEASON_STRENGTH));
    }
#endif
#if DIMENSION == 0 && SURFACE_SEASONS == 1
    vec4 swSnow=seasonWeights();
    float snowBiome=float(biome_precipitation==2);
    float coldWinter=smoothstep(0.75,0.98,biomeCold())*max(swSnow.w,0.0);
    float snowNow=max(snowBiome*max(weatherRainAmount(),0.30),coldWinter);
    float upwardSnow=smoothstep(0.65,0.95,m.normal.y);
    float snowMask=sat(snowNow*upwardSnow);
    m.albedo=mix(m.albedo,vec3(0.78,0.80,0.84),snowMask*0.55);
    m.roughness=mix(m.roughness,0.40,snowMask*0.50);
    if(seasonFoliage>0.5 && snowNow>0.0) {
        m.albedo=mix(m.albedo,vec3(0.62,0.66,0.72),sat(snowNow*0.35));
    }
#endif
    vec3 color=shadeSurface(m,vPlayer,vLight,vId);
#if WET_SURFACES == 1 && DIMENSION == 0
    vec3 splashLight=mix(vec3(0.08,0.10,0.13),sunlightColor(),dayAmount());
    splashLight+=lightningBoltPosition.w*vec3(0.65,0.78,1.0);
    color+=splashLight*rainSplash*0.038;
#endif
    float hand=0.0;
#ifdef HAND
    hand=1.0;
#endif
    gl_FragData[0]=vec4(color,tex.a);
    gl_FragData[1]=vec4(m.normal*0.5+0.5,m.roughness);
    gl_FragData[2]=vec4(m.albedo,m.metal>0.5 ? -1.0 : m.f0.r);
    gl_FragData[3]=vec4(vLight.y,m.emission,hand,1.0);
}
