#ifndef SE_SHADOWS
#define SE_SHADOWS
#include "/lib/noise.glsl"
uniform sampler2D shadowtex0;
vec3 shadowCoordinate(vec3 player) {
    vec4 p = shadowProjection*shadowModelView*vec4(player,1.0);
    return p.xyz/max(abs(p.w),1e-6)*0.5+0.5;
}
float shadowVisibility(vec3 player, vec3 normal, bool soft) {
#if DIMENSION == -1
    return 1.0;
#else
    float texelWorld = 2.0*shadowDistance/float(shadowMapResolution);
    float slope = 1.0-sat(dot(normal,lightDirection()));
    vec3 coord = shadowCoordinate(player+normal*texelWorld*(0.55+0.9*slope));
    if (any(lessThan(coord,vec3(0.003))) || any(greaterThan(coord,vec3(0.997)))) return 1.0;
    float bias = 0.00008+0.00015*slope;
    if (!soft) return step(coord.z-bias,texture2D(shadowtex0,coord.xy).r);

#if SHADOW_QUALITY == 1
    // The low profile has no blocker search, so its four taps always use the
    // same radius. It previously rotated the kernel with valueNoise + sin/cos
    // for every soft-shadow pixel. A fixed cross plus a 2x2 screen jitter keeps
    // the four-tap budget and removes that noise and trigonometry entirely.
    vec2 jitter = (vec2(mod(gl_FragCoord.x, 2.0), mod(gl_FragCoord.y, 2.0)) - 0.5) * 0.35;
    const vec2 taps[4] = vec2[4](vec2(1.0, 0.0), vec2(0.0, 1.0),
                                 vec2(-1.0, 0.0), vec2(0.0, -1.0));
    float lowVisibility = 0.0;
    for (int i = 0; i < 4; ++i) {
        vec2 offset = (taps[i] + jitter) * 0.8 / float(shadowMapResolution);
        lowVisibility += step(coord.z - bias, texture2D(shadowtex0, coord.xy + offset).r);
    }
    lowVisibility *= 0.25;
    float lowFade = smoothstep(shadowDistance*0.75, shadowDistance*0.98,
                               length(player.xz));
    return mix(lowVisibility, 1.0, lowFade);
#else
    float distanceFade = length(player.xz) / shadowDistance;
    float sunStretch = 1.0 + 1.35 * (1.0 - abs(sunDirection().y));
    float angle = valueNoise((player.xz + cameraPosition.xz) * 0.25) * 2.0 * PI;
    mat2 rotation = mat2(cos(angle), -sin(angle), sin(angle), cos(angle));

#if SHADOW_QUALITY == 2
    const int blockerSamples = 3;
    const int filterSamples = 6;
#elif SHADOW_QUALITY == 3
    // Blocker search and filter taps follow the reference pack's defaults
    // (three blocker samples, six to twelve filter taps) instead of the
    // previous 8 + 12, which cost roughly a third more shadow fetches per lit
    // fragment. Higher profiles keep a wider penumbra budget.
    const int blockerSamples = 4;
    const int filterSamples = 10;
#elif SHADOW_QUALITY == 4
    const int blockerSamples = 6;
    const int filterSamples = 12;
#else
    const int blockerSamples = 8;
    const int filterSamples = 16;
#endif

    // PCSS blocker search: only depths in front of the receiver can cast here.
    float blockerDepth = 0.0;
    float blockers = 0.0;
#if SHADOW_QUALITY > 1
    float searchRadius = (2.5 + 1.5 * distanceFade) * sunStretch * sqrt(SHADOW_SOFTNESS) /
                         float(shadowMapResolution);
    for (int i = 0; i < blockerSamples; ++i) {
        vec2 searchOffset=i==0 ? vec2(0.0) : diskSample(i-1,max(blockerSamples-1,1));
        vec2 sampleUV = coord.xy + rotation * searchOffset * searchRadius;
        float sampleDepth = texture2D(shadowtex0, sampleUV).r;
        if (sampleDepth < coord.z - bias) {
            blockerDepth += sampleDepth;
            blockers += 1.0;
        }
    }
#endif

    float filterRadiusTexels = 0.8;
    if (blockers > 0.0) {
        blockerDepth /= blockers;
        // Contact hardening: receiver/blocker separation grows the penumbra.
        // Orthographic depths have no perspective divide by blocker depth.
        // Recover separation in blocks so softness survives resolution changes.
        float separation = max(coord.z - blockerDepth, 0.0)*2.0 /
                           max(abs(shadowProjection[2][2]),1e-5);
        float lightSize = tan(SUN_ANGULAR_RADIUS*(PI/180.0))*SHADOW_SOFTNESS / texelWorld;
        filterRadiusTexels = clamp(0.55 + separation * lightSize, 0.55,
                                   2.2 + float(SHADOW_QUALITY) * 0.9);
    }
    // Preserve the 1.3 far-distance budget reduction.
    int count = distanceFade > 0.6 ? min(filterSamples, 4) : filterSamples;
    float visibility = 0.0;
    for (int i = 0; i < filterSamples; ++i) {
        if (i >= count) break;
        vec2 offset = rotation * diskSample(i, count) * filterRadiusTexels /
                      float(shadowMapResolution);
        visibility += step(coord.z-bias,texture2D(shadowtex0,coord.xy+offset).r);
    }
    visibility /= float(count);
    float fade = smoothstep(shadowDistance*0.75,shadowDistance*0.98,length(player.xz));
    return mix(visibility,1.0,fade);
#endif
#endif
}
#endif
