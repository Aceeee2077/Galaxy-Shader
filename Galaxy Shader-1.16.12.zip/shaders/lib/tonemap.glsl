#ifndef SE_TONEMAP
#define SE_TONEMAP
vec3 legacyFilmic(vec3 x) {
    // A bounded rational film response, applied only after exposure and HDR effects.
    vec3 a=x*(2.51*x+0.03);
    vec3 b=x*(2.43*x+0.59)+0.14;
    return clamp(a/b,0.0,1.0);
}
vec3 acesLike(vec3 x) {
    // Slightly softer shoulder than the legacy fit, preserving dark midtones.
    x=max(x,vec3(0.0));
    return clamp((x*(2.30*x+0.035))/(x*(2.18*x+0.58)+0.14),0.0,1.0);
}
vec3 naturalFilmic(vec3 x) {
    // Luminance shoulder preserves hue and true black. The old log sigmoid
    // mapped 0.01 linear to a bright grey, flattening shadows and the End sky.
    x=max(x,vec3(0.0));
    float lum=max(luminance(x),1e-6);
    float shaped=(lum*(2.0*lum+0.025))/(lum*(2.0*lum+0.65)+0.15);
    vec3 mapped=x*(shaped/lum);
    // Gently lose chroma as highlights approach display white, keeping sunlit
    // stone and cloud rims pearly instead of fluorescent. Greys are unchanged.
    mapped=mix(mapped,vec3(shaped),smoothstep(0.45,0.98,shaped)*0.12);
    // Bring only out-of-gamut highlights toward white, avoiding channel clipping.
    float peak=max(mapped.r,max(mapped.g,mapped.b));
    float highlight=sat((peak-1.0)/max(peak-shaped,1e-5));
    mapped=mix(mapped,vec3(shaped),highlight);
    return clamp(mapped,0.0,1.0);
}
float adaptedExposure() {
    float gain=1.0;
#if AUTO_EXPOSURE == 1
    float sky=sat(float(eyeBrightnessSmooth.y)/240.0);
    float block=sat(float(eyeBrightnessSmooth.x)/240.0);
    float illumination=max(sky*mix(0.16,1.0,dayAmount()),block*0.45);
    // Iris smooths the eye lightmap over time; a lower peak keeps caves dark
    // and daylight from washing out, giving the image a softer shoulder.
    gain=mix(1.12,0.84,sqrt(illumination));
#endif
    return gain*EXPOSURE;
}
vec3 gradeColor(vec3 hdr) {
    vec3 exposed=max(hdr,vec3(0))*adaptedExposure();
    // Balance in HDR so bright stone and clouds roll toward white with the
    // tone curve. A daytime warmth keeps blue skies and green foliage distinct.
#if DIMENSION == 0
    exposed*=mix(vec3(1.025,1.0,0.965),vec3(1.045,1.005,0.945),dayAmount());
#endif
#if TONEMAP_MODE == 0
    vec3 c=legacyFilmic(exposed);
#elif TONEMAP_MODE == 1
    vec3 c=acesLike(exposed);
#else
    vec3 c=naturalFilmic(exposed);
#endif
    c=mix(vec3(luminance(c)),c,SATURATION);
    c=(c-0.5)*CONTRAST+0.5;
    return pow(clamp(c,0.0,1.0),vec3(1.0/2.2));
}
#endif
